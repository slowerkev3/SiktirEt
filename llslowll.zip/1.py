import requests
import os

from bs4 import BeautifulSoup

print("""

    .____    .__         .__                .__  .__    
    |    |   |  |   _____|  |   ______  _  _|  | |  |   
    |    |   |  |  /  ___/  |  /  _ \ \/ \/ /  | |  |  
    |    |___|  |__\___ \|  |_(  <_> )     /|  |_|  |__ 
    |_______ \____/____  >____/\____/ \/\_/ |____/____/
        \/         \/                              
""")


with open("sitelist.txt", "r") as file:
    SiteList = file.read().split()

print(type(SiteList))
bftimeout = 100
def Basla(UrlGir):
    

    r = requests.get(UrlGir, timeout=float(bftimeout), allow_redirects=False)
    soup = BeautifulSoup(r.content, "html.parser")
    soup.pettify
    soup_string = str(soup)

    x = soup_string.find("aranacakkelime")
    y = soup_string.find("aranacakkelime")
    if x == -1:
        pass
    else:
        print(UrlGir)
        with open("Sonuc.txt", "a") as file:
            file.write(UrlGir+"\n")

    if y == -1:
        pass
    else:
        print(UrlGir)
        with open("Sonuc.txt", "a") as file:
            file.write(UrlGir+"\n")

kol = map(Basla,SiteList)
print(list(kol))
















